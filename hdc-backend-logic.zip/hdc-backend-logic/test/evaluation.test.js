import test from "node:test";
import assert from "node:assert/strict";
import { PRODUCTS, getProduct, listPublishedProducts } from "../src/catalogue.js";
import { assessCompatibility, canonicalize, createJobSnapshot, evaluateSubmission, lookupExactPrice, validateConfiguration } from "../src/evaluation.js";
import { lookupBaseSheetPrice } from "../src/pricebook.js";
import { evaluateArtworkPreflight } from "../src/preflight.js";
import { COLOR_PRICE_RULES, MINIMUM_ORDER_RULES, PROCESS_USAGE_GUIDANCE, validateCommercialRequirements } from "../src/commercial-rules.js";

const brochures = getProduct("brochures");
const bottle = getProduct("printed-bottles");
const approvedBrochure = { ...brochures, publicationStatus: "approved", commercialMode: "MATRIX" };
const profile = {
  status: "approved",
  version: 3,
  fields: {
    size: { label: "Size", type: "string", required: true, values: ["A4", "A5"] },
    quantity: { label: "Quantity", type: "number", required: true },
    fold: { label: "Fold", type: "string", required: false, values: ["half", "tri"] },
  },
};

test("catalogue preserves source products plus the owner-confirmed catalogue product", () => {
  assert.equal(PRODUCTS.length, 20);
  assert.equal(new Set(PRODUCTS.map((item) => item.familyId)).size, 5);
  assert.equal(listPublishedProducts().length, 0, "draft records must not leak into public catalogue");
});

test("catalogues and posters enforce a 500-piece MOQ and 1, 2 or 4 colour pricing basis", () => {
  for (const id of ["catalogues", "posters"]) {
    const product = getProduct(id);
    assert.deepEqual(MINIMUM_ORDER_RULES[id].minimumQuantity, 500);
    assert.deepEqual(COLOR_PRICE_RULES[id].allowedValues, [1, 2, 4]);
    assert.equal(validateCommercialRequirements(product, { quantity: 499, print_colors: 1 }).valid, false);
    assert.equal(validateCommercialRequirements(product, { quantity: 500, print_colors: 3 }).issues[0].code, "UNSUPPORTED_COLOR_COUNT");
    assert.equal(validateCommercialRequirements(product, { quantity: 500, print_colors: 4 }).valid, true);
  }
});

test("catalogue submissions below MOQ stop and print colours participate in exact matrix pricing", () => {
  const product = { ...getProduct("catalogues"), publicationStatus: "approved", commercialMode: "MATRIX" };
  const profile = {
    status: "approved", version: 1,
    fields: {
      quantity: { type: "number", required: true },
      print_colors: { type: "number", required: true, values: [1, 2, 4] },
    },
  };
  const belowMinimum = evaluateSubmission({ product, configuration: { quantity: 499, print_colors: 2 }, profile });
  assert.equal(belowMinimum.status, "invalid");
  assert.equal(belowMinimum.issues[0].code, "BELOW_MINIMUM_ORDER");

  const configuration = { quantity: 500, print_colors: 2 };
  const row = {
    id: "catalogue-2c", status: "approved", productId: product.id, profileVersion: 1,
    configurationKey: canonicalize(configuration), currency: "PKR", unitPrice: 9000,
    quantityRange: { min: 500, max: 5000 }, matrixVersion: 1,
  };
  assert.equal(lookupExactPrice(product, configuration, profile, [row]).status, "priced");
  assert.equal(lookupExactPrice(product, { ...configuration, print_colors: 4 }, profile, [row]).status, "no_exact_match");
});

test("common UV process guidance does not approve every product route", () => {
  assert.deepEqual(PROCESS_USAGE_GUIDANCE.commonProcesses, ["uv-printing", "uv-dtf"]);
  assert.equal(PROCESS_USAGE_GUIDANCE.scope, "most-products");
  assert.equal(PROCESS_USAGE_GUIDANCE.productSpecificApprovalRequired, true);
});

test("unapproved configuration profile routes to review", () => {
  const result = validateConfiguration(brochures, { size: "A4" }, null);
  assert.equal(result.valid, false);
  assert.equal(result.needsReview, true);
  assert.equal(result.issues[0].code, "CONFIGURATION_PROFILE_UNAPPROVED");
});

test("approved profile rejects unknown fields, missing required values and invented options", () => {
  const result = validateConfiguration(brochures, { size: "A3", quantity: "250", invented: true }, profile);
  assert.equal(result.valid, false);
  assert.deepEqual(new Set(result.issues.map((issue) => issue.code)), new Set(["OPTION_NOT_APPROVED", "INVALID_FIELD_TYPE", "UNKNOWN_FIELD"]));
});

test("Template B without an exact approved compatibility rule requires technical review", () => {
  const result = assessCompatibility(bottle, { surface: "glass", geometry: "curved" }, []);
  assert.equal(result.status, "needs_review");
  assert.equal(result.matchedRuleId, null);
});

test("compatibility uses the most specific approved matching rule", () => {
  const rules = [
    { id: "broad", productId: bottle.id, status: "approved", when: { surface: "glass" }, outcome: "needs_test" },
    { id: "specific", productId: bottle.id, status: "approved", when: { surface: "glass", geometry: "straight" }, outcome: "available" },
  ];
  const result = assessCompatibility(bottle, { surface: "glass", geometry: "straight" }, rules);
  assert.equal(result.status, "available");
  assert.equal(result.matchedRuleId, "specific");
});

test("pricing requires an exact active approved row; nearby quantity does not match", () => {
  const configuration = { size: "A4", quantity: 250 };
  const row = {
    id: "approved-row-1", status: "approved", productId: approvedBrochure.id, profileVersion: 3,
    configurationKey: canonicalize(configuration), currency: "PKR", unitPrice: 100,
    quantityRange: { min: 200, max: 300 }, matrixVersion: 2,
    effectiveFrom: "2026-01-01T00:00:00.000Z", effectiveTo: "2026-12-31T23:59:59.999Z",
  };
  const exact = lookupExactPrice(approvedBrochure, configuration, profile, [row], new Date("2026-10-01T00:00:00.000Z"));
  assert.equal(exact.status, "priced");
  const different = lookupExactPrice(approvedBrochure, { ...configuration, size: "A5" }, profile, [row], new Date("2026-10-01T00:00:00.000Z"));
  assert.equal(different.status, "no_exact_match");
});

test("submission never publishes unapproved records", () => {
  const result = evaluateSubmission({ product: brochures, configuration: {}, profile });
  assert.equal(result.status, "blocked");
  assert.equal(result.nextAction, "ADMIN_REVIEW");
});

test("job snapshot is immutable and preserves the submitted configuration", () => {
  const snapshot = createJobSnapshot({ product: brochures, configuration: { size: "A4", quantity: 250 }, evaluation: { status: "quote_required" }, createdAt: "2026-10-05T12:00:00.000Z" });
  assert.equal(snapshot.configuration.quantity, 250);
  assert.equal(Object.isFrozen(snapshot), true);
  assert.equal(Object.isFrozen(snapshot.configuration), true);
});

test("owner-supplied A3 sticker and label sheet price is recorded without inventing a total", () => {
  const labels = lookupBaseSheetPrice(getProduct("labels-stickers"), { finished_size: "A3" });
  assert.equal(labels.status, "base_price");
  assert.equal(labels.currency, "PKR");
  assert.equal(labels.unitPrice, 2500);
  assert.equal(labels.unit, "sheet");
  assert.equal(labels.totalCalculated, false);

  const stickers = lookupBaseSheetPrice(getProduct("custom-sticker-sheets"), { sheet_size: "A3" });
  assert.equal(stickers.unitPrice, 2500);
  assert.equal(stickers.nextAction, "CONFIRM_JOB_SCOPE");
});

test("extra A3 sheet options retain the base price but require a quote", () => {
  const result = lookupBaseSheetPrice(getProduct("custom-sticker-sheets"), { sheet_size: "A3", lamination: "gloss" });
  assert.equal(result.status, "base_price_quote_required");
  assert.equal(result.unitPrice, 2500);
  assert.equal(result.totalCalculated, false);
  assert.equal(result.nextAction, "REQUEST_QUOTE");
});

test("artwork preflight requires a matching approved process profile", () => {
  const missing = evaluateArtworkPreflight({ processId: "packaging-offset" });
  assert.equal(missing.status, "needs_profile");

  const mismatch = evaluateArtworkPreflight({ processId: "uv-dtf", profile: { id: "offset-v1", version: 1, status: "approved", processId: "packaging-offset", requiredChecks: [] } });
  assert.equal(mismatch.status, "needs_review");
  assert.equal(mismatch.issues[0].code, "PROCESS_PROFILE_MISMATCH");
});

test("preflight never reports pass when a required check is missing or blocked", () => {
  const profile = { id: "offset-packaging", version: 2, status: "approved", processId: "packaging-offset", requiredChecks: [{ id: "pdf-integrity" }, { id: "output-intent" }] };
  const missing = evaluateArtworkPreflight({ processId: "packaging-offset", profile, findings: [{ check: "pdf-integrity", status: "pass" }] });
  assert.equal(missing.status, "needs_review");
  const blocked = evaluateArtworkPreflight({ processId: "packaging-offset", profile, findings: [{ check: "pdf-integrity", status: "pass" }, { check: "output-intent", status: "error", detail: "Mismatch" }] });
  assert.equal(blocked.status, "blocked");
  assert.equal(blocked.nextAction, "FIX_ARTWORK");
});
