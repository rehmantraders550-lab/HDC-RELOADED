# HDC Printing Domain Logic — 0.1.0

Framework-independent backend rules for the HDC product catalogue. This package is an ORVIA-governed starting layer, not a connected production backend.

## Implemented

- 20 catalogue product records and 5 families, including a catalogue product entry to carry the owner-confirmed catalogue rules.
- Publication guard: only explicitly approved records are public.
- Configuration validation against a separately approved profile.
- Owner-confirmed catalogue and poster rules: 500-piece minimum and 1, 2 or 4 print colours. The number of colours is a pricing dimension in the exact approved price matrix; no price amounts are invented.
- Owner-confirmed A3 sticker/label sheet base price: PKR 2,500 per sheet, with no automatic quantity total or assumed add-on pricing.
- UV printing and UV DTF recorded as common across most products, while product-specific routes remain subject to approval.
- Surface compatibility resolution using explicit approved rules; no rule means technical review.
- Exact approved price-matrix lookup; no client-side estimate or fallback formula.
- Immutable job-request snapshots that preserve the submitted configuration and evaluation.
- Failure states and actions are returned as structured data for a future API/UI adapter.

## Intentionally not configured

The source catalogue supplies field names, not approved option sets, required-field decisions, production compatibility rules, full pricing rows, file policies or publication approvals. Accordingly:

- all product records start in `draft`;
- all configuration profiles start unapproved;
- exact price matrices and compatibility rules are empty (the A3 sheet entry is a separately identified base price only);
- no product is directly order-ready;
- DTF and finished DTF apparel have no special public visibility until HDC confirms the offer.

This is deliberate. Add production-approved profiles, prices and rules before enabling order-ready submissions. Sample pricing and compatibility rules in tests are fixtures only and are not HDC data. The catalogue/poster MOQ and colour-count rules and A3 base price are explicitly marked as owner-supplied inputs.

## Run checks

Requires Node.js 20 or newer. No third-party package is required.

```sh
npm test
```

## Integration contract

The future server adapter should call `getProduct`, load the approved configuration/compatibility/pricing records from the persistent store, run `evaluateSubmission`, and then either return validation feedback, create a quote/technical-review request, or expose an approved exact price. `createJobSnapshot` creates the immutable payload; database writes, authentication, file storage and notifications belong in the application adapter after the actual HDC repository and hosting stack are confirmed.

Suggested routes (not implemented):

- `GET /api/catalogue` — approved public products only.
- `GET /api/products/:id` — public product data and approved form profile.
- `POST /api/jobs/evaluate` — validate selections and return next action.
- `POST /api/jobs` — persist a quote or technical-review snapshot.
- `POST /api/admin/products/:id/approve` — restricted ORVIA-gated publication/configuration approval.

## ORVIA gates

1. **Source gate:** every product/profile/rule has source and owner metadata.
2. **Approval gate:** only approved records can publish, match pricing or establish compatibility.
3. **Evaluation gate:** missing or conflicting production data routes to review.
4. **Snapshot gate:** submissions retain their selected values and rule outcomes for audit.
5. **Release gate:** connect to the confirmed HDC repository; test preview behavior before production.

## Source boundaries

EPS and packaging research informed the validation approach: preflight checks must use a matching approved process profile, and engineering feasibility does not equal production approval. EPS-specific dieline, tolerance or substrate values are not copied into HDC rules. UV and UV DTF are kept as distinct process identifiers; the “most products” guidance does not automatically approve either process for any individual product.

No image-generation command, API, dependency or runtime generation capability is included in this package. Website imagery must come from HDC's existing approved assets.
