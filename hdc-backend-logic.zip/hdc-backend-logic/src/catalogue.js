/**
 * Canonical catalogue metadata from the HDC printing catalogue specification.
 * Runtime option values and product-specific production routes are intentionally
 * absent until approved by HDC. Owner-confirmed commercial rules are maintained
 * separately in commercial-rules.js.
 */

export const FAMILIES = Object.freeze([
  { id: "dtf-transfers", name: "DTF Transfers" },
  { id: "finished-dtf-apparel", name: "Finished DTF Apparel" },
  { id: "uv-printing-decals", name: "UV Printing + Decals" },
  { id: "commercial-print-branding", name: "Commercial Print + Branding" },
  { id: "large-format-display", name: "Large Format + Display" },
]);

const field = (key, label) => Object.freeze({ key, label });
const product = (id, name, familyId, template, fieldList, sourceRef) => Object.freeze({
  id,
  name,
  familyId,
  template,
  fields: Object.freeze(fieldList),
  sourceRef,
  publicationStatus: "draft",
  configurationProfileStatus: "unapproved",
  commercialMode: template === "B" ? "TECHNICAL_REVIEW" : "QUOTE",
  compatibilityStatus: template === "B" ? "unverified" : "not_applicable",
});

export const PRODUCTS = Object.freeze([
  product("custom-dtf-transfers", "Custom DTF Transfers", "dtf-transfers", "A", [field("finished_size", "Finished transfer size"), field("artwork_dimensions", "Artwork width / height"), field("quantity", "Quantity"), field("design_versions", "Artwork designs / versions"), field("artwork", "Colour artwork"), field("production_notes", "Production notes")], "Catalogue §3.1"),
  product("gang-sheets", "Gang Sheets", "dtf-transfers", "A", [field("sheet_size", "Sheet size"), field("artwork_count", "Artwork count"), field("artwork_dimensions", "Artwork dimensions"), field("design_versions", "Artwork versions"), field("quantity", "Quantity"), field("layout_assistance", "Layout assistance"), field("artwork", "Artwork")], "Catalogue §3.2"),
  product("bulk-transfers", "Bulk Transfers", "dtf-transfers", "A", [field("transfer_size", "Transfer size"), field("quantity", "Quantity"), field("design_count", "Number of designs"), field("repeat_requirements", "Repeat-production requirements"), field("artwork", "Artwork")], "Catalogue §3.3"),
  product("t-shirts", "T-Shirts", "finished-dtf-apparel", "A", [field("garment_type", "Garment type"), field("sizes", "Garment size"), field("garment_colour", "Garment colour"), field("print_position", "Print position"), field("print_dimensions", "Print dimensions"), field("quantity", "Quantity"), field("design_versions", "Artwork versions"), field("artwork", "Artwork")], "Catalogue §4.1"),
  product("hoodies", "Hoodies", "finished-dtf-apparel", "A", [field("hoodie_style", "Hoodie style"), field("sizes", "Size"), field("garment_colour", "Colour"), field("print_positions", "Front / back / sleeve positions"), field("print_dimensions", "Print dimensions"), field("quantity", "Quantity"), field("artwork", "Artwork")], "Catalogue §4.2"),
  product("jerseys-uniforms", "Jerseys / Uniforms", "finished-dtf-apparel", "A", [field("garment_type", "Garment type"), field("size_breakdown", "Size breakdown"), field("quantity", "Quantity"), field("logo_positions", "Logo positions"), field("variable_data", "Names / numbers"), field("artwork", "Artwork")], "Catalogue §4.3"),
  product("caps", "Caps", "finished-dtf-apparel", "A", [field("cap_style", "Cap style"), field("garment_colour", "Colour"), field("print_location", "Print location"), field("artwork_dimensions", "Artwork dimensions"), field("quantity", "Quantity"), field("artwork", "Artwork")], "Catalogue §4.4"),
  product("uv-dtf-decals", "UV DTF Decals", "uv-printing-decals", "B", [field("surface_material", "Surface material"), field("object_type", "Object type"), field("geometry", "Geometry"), field("printable_area", "Printable area"), field("artwork_dimensions", "Artwork dimensions"), field("quantity", "Quantity"), field("white_ink", "White ink requirement"), field("finish", "Finish / varnish"), field("artwork", "Artwork")], "Catalogue §5.1"),
  product("labels-stickers", "Labels & Stickers", "uv-printing-decals", "A", [field("shape", "Shape"), field("finished_size", "Finished size"), field("material", "Material / adhesive stock"), field("print_method", "Print method"), field("quantity", "Quantity"), field("lamination", "Lamination"), field("cut_type", "Cut type"), field("design_versions", "Artwork versions"), field("artwork", "Artwork")], "Catalogue §5.2"),
  product("custom-sticker-sheets", "Custom Sticker Sheets", "uv-printing-decals", "A", [field("sheet_size", "Sheet size"), field("sticker_type", "Sticker type"), field("sticker_count", "Sticker count"), field("material", "Material"), field("finish", "Finish"), field("cut_style", "Cut style"), field("quantity", "Quantity"), field("design_count", "Number of designs"), field("artwork", "Artwork")], "Catalogue §5.3"),
  product("uv-printed-bottles", "UV Printed Bottles", "uv-printing-decals", "B", [field("bottle_type", "Bottle type"), field("material", "Material"), field("surface_coating", "Surface finish / coating"), field("geometry", "Geometry"), field("printable_area", "Printable area"), field("candidate_process", "Candidate print process"), field("white_ink", "White ink"), field("varnish", "Varnish / gloss"), field("quantity", "Quantity"), field("design_count", "Number of designs"), field("artwork", "Artwork")], "Catalogue §5.4"),
  product("packaging-print", "Packaging Print", "commercial-print-branding", "A", [field("finished_size", "Finished size"), field("construction", "Construction / format"), field("board_paper", "Board / paper"), field("gsm", "GSM"), field("print_sides", "Print sides"), field("colour", "Colour"), field("lamination", "Lamination"), field("finishing", "Finishing"), field("quantity", "Quantity"), field("artwork_dieline", "Artwork / dieline")], "Catalogue §6.1"),
  product("branded-promotional-products", "Branded / Promotional Products", "commercial-print-branding", "B", [field("object_type", "Object type"), field("material", "Material / surface"), field("geometry", "Geometry"), field("printable_area", "Printable area"), field("quantity", "Quantity"), field("finish", "Finish"), field("artwork", "Artwork")], "Catalogue §6.2"),
  product("brochures", "Brochures", "commercial-print-branding", "A", [field("finished_size", "Finished size"), field("flat_size", "Flat size"), field("fold_type", "Fold type"), field("paper", "Paper"), field("gsm", "GSM"), field("print_sides", "Print sides"), field("colour", "Colour"), field("lamination", "Lamination"), field("quantity", "Quantity"), field("design_versions", "Artwork versions"), field("artwork", "Artwork")], "Catalogue §6.3"),
  product("catalogues", "Catalogues", "commercial-print-branding", "A", [field("finished_size", "Finished size"), field("page_count", "Page count"), field("paper", "Paper"), field("gsm", "GSM"), field("print_sides", "Print sides"), field("print_colors", "Print colours"), field("binding", "Binding"), field("quantity", "Quantity"), field("artwork", "Artwork")], "Owner-confirmed product and commercial rules"),
  product("certificates", "Certificates", "commercial-print-branding", "A", [field("finished_size", "Finished size"), field("paper_card", "Paper / card"), field("gsm", "GSM"), field("colour", "Colour"), field("print_sides", "Single / double-sided"), field("quantity", "Quantity"), field("variable_data", "Names / serialisation"), field("finishing", "Finishing"), field("artwork", "Artwork")], "Catalogue §6.4"),
  product("printed-bottles", "Printed Bottles", "commercial-print-branding", "B", [field("bottle_type", "Bottle type"), field("material", "Material"), field("geometry", "Geometry"), field("printable_area", "Printable area"), field("intended_use", "Intended use"), field("quantity", "Quantity"), field("design_count", "Number of designs"), field("surface_coating", "Surface / coating details"), field("artwork", "Artwork")], "Catalogue §6.5"),
  product("signage-displays", "Signage / Retail & Event Displays", "large-format-display", "A", [field("display_type", "Display type"), field("finished_dimensions", "Finished dimensions"), field("material", "Material"), field("print_method", "Print method"), field("hardware", "Stand / hardware"), field("quantity", "Quantity"), field("finishing", "Finishing"), field("artwork", "Artwork")], "Catalogue §7.1"),
  product("posters", "Posters", "large-format-display", "A", [field("finished_size", "Finished size"), field("material", "Material"), field("print_type", "Print type"), field("print_colors", "Print colours"), field("quantity", "Quantity"), field("artwork_variation", "Same / variable artwork"), field("lamination", "Lamination"), field("artwork", "Artwork")], "Catalogue §7.2"),
  product("uv-printed-wall-vinyls", "UV Printed Wall Vinyls", "large-format-display", "A", [field("wall_dimensions", "Wall dimensions"), field("finished_size", "Finished graphic size"), field("vinyl_type", "Vinyl / film type"), field("surface_condition", "Surface condition"), field("environment", "Indoor / outdoor environment"), field("quantity", "Quantity"), field("installation", "Installation requirement"), field("artwork", "Artwork")], "Catalogue §7.3"),
]);

const productsById = new Map(PRODUCTS.map((item) => [item.id, item]));

export function getProduct(productId) {
  return productsById.get(productId) ?? null;
}

/** Only explicitly approved records can appear in a public catalogue. */
export function listPublishedProducts(products = PRODUCTS) {
  return products.filter((item) => item.publicationStatus === "approved");
}

export function listFamilies() {
  return FAMILIES;
}
