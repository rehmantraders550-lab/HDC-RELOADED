import { validateCommercialRequirements } from "./commercial-rules.js";

const isPlainObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const isEmpty = (value) => value === undefined || value === null || value === "" || (Array.isArray(value) && value.length === 0);

function matchesRule(configuration, when = {}) {
  return Object.entries(when).every(([key, expected]) => configuration[key] === expected);
}

/**
 * Validates against a production-approved profile. The catalogue's field list
 * alone is not an approved form schema, so missing/unapproved profiles stop
 * the job from being treated as order-ready.
 */
export function validateConfiguration(product, configuration, profile) {
  const issues = [];
  if (!isPlainObject(configuration)) {
    return { valid: false, issues: [{ code: "CONFIGURATION_NOT_OBJECT", message: "Configuration must be an object." }] };
  }
  if (!profile || profile.status !== "approved") {
    return {
      valid: false,
      needsReview: true,
      issues: [{ code: "CONFIGURATION_PROFILE_UNAPPROVED", message: "An approved configuration profile is required before this job can be validated." }],
    };
  }

  const fields = profile.fields ?? {};
  for (const key of Object.keys(configuration)) {
    if (!Object.hasOwn(fields, key)) issues.push({ code: "UNKNOWN_FIELD", field: key, message: `Field '${key}' is not part of the approved configuration.` });
  }
  for (const [key, definition] of Object.entries(fields)) {
    const value = configuration[key];
    if (definition.required && isEmpty(value)) {
      issues.push({ code: "REQUIRED_FIELD_MISSING", field: key, message: `'${definition.label ?? key}' is required.` });
      continue;
    }
    if (isEmpty(value)) continue;
    if (definition.type === "string" && typeof value !== "string") issues.push({ code: "INVALID_FIELD_TYPE", field: key, message: `'${key}' must be text.` });
    if (definition.type === "number" && (typeof value !== "number" || !Number.isFinite(value))) issues.push({ code: "INVALID_FIELD_TYPE", field: key, message: `'${key}' must be a finite number.` });
    if (definition.type === "boolean" && typeof value !== "boolean") issues.push({ code: "INVALID_FIELD_TYPE", field: key, message: `'${key}' must be true or false.` });
    if (definition.type === "string[]" && (!Array.isArray(value) || value.some((entry) => typeof entry !== "string"))) issues.push({ code: "INVALID_FIELD_TYPE", field: key, message: `'${key}' must be a list of text values.` });
    if (definition.values && !definition.values.includes(value)) issues.push({ code: "OPTION_NOT_APPROVED", field: key, message: `The selected value for '${key}' is not approved.` });
  }
  return { valid: issues.length === 0, issues };
}

/**
 * Compatibility rules are explicit approved records. No matching rule means
 * review, never an inferred approval based only on the object name.
 */
export function assessCompatibility(product, configuration, rules = []) {
  if (product.template !== "B") return { status: "not_applicable", matchedRuleId: null, reason: "This product does not use the surface/application compatibility template." };
  const candidates = rules.filter((rule) => rule.productId === product.id && rule.status === "approved" && matchesRule(configuration, rule.when));
  if (candidates.length === 0) return { status: "needs_review", matchedRuleId: null, reason: "No approved compatibility rule matches this object and surface configuration." };
  const highestSpecificity = Math.max(...candidates.map((rule) => Object.keys(rule.when ?? {}).length));
  const best = candidates.filter((rule) => Object.keys(rule.when ?? {}).length === highestSpecificity);
  const outcomes = new Set(best.map((rule) => rule.outcome));
  if (outcomes.size !== 1) return { status: "needs_review", matchedRuleId: null, reason: "Approved rules conflict at the same specificity; manual review is required." };
  const rule = best[0];
  if (!["available", "needs_test", "unsupported"].includes(rule.outcome)) return { status: "needs_review", matchedRuleId: rule.id, reason: "The compatibility rule has no recognized outcome." };
  return { status: rule.outcome, matchedRuleId: rule.id, reason: rule.reason ?? null };
}

export function canonicalize(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(",")}]`;
  if (isPlainObject(value)) {
    const keys = Object.keys(value).sort();
    return `{${keys.map((key) => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

/** Price only on an exact approved config match and an active quantity band. */
export function lookupExactPrice(product, configuration, profile, matrixRows = [], asOf = new Date()) {
  if (!profile || profile.status !== "approved") return { status: "unavailable", reason: "Configuration profile is not approved." };
  const configurationKey = canonicalize(configuration);
  const now = new Date(asOf).getTime();
  const quantity = configuration.quantity;
  const row = matrixRows.find((candidate) => {
    if (candidate.status !== "approved" || candidate.productId !== product.id || candidate.profileVersion !== profile.version) return false;
    if (candidate.configurationKey !== configurationKey) return false;
    if (candidate.currency !== "PKR" || !Number.isFinite(candidate.unitPrice) || candidate.unitPrice < 0) return false;
    const from = candidate.effectiveFrom ? new Date(candidate.effectiveFrom).getTime() : -Infinity;
    const to = candidate.effectiveTo ? new Date(candidate.effectiveTo).getTime() : Infinity;
    if (!(now >= from && now <= to)) return false;
    const band = candidate.quantityRange;
    return typeof quantity === "number" && band && quantity >= band.min && quantity <= band.max;
  });
  if (!row) return { status: "no_exact_match", reason: "No active approved price row matches this exact configuration and quantity." };
  return { status: "priced", currency: row.currency, amount: row.unitPrice, matrixVersion: row.matrixVersion, rowId: row.id };
}

export function evaluateSubmission({ product, configuration, profile, compatibilityRules = [], matrixRows = [], asOf = new Date() }) {
  if (!product) return { status: "invalid", nextAction: "SELECT_VALID_PRODUCT", issues: [{ code: "PRODUCT_NOT_FOUND", message: "The selected product does not exist." }] };
  if (product.publicationStatus !== "approved") {
    return { status: "blocked", nextAction: "ADMIN_REVIEW", issues: [{ code: "PRODUCT_NOT_PUBLISHED", message: "This product is not approved for public submission." }] };
  }
  const validation = validateConfiguration(product, configuration, profile);
  if (validation.needsReview) return { status: "review", nextAction: "CONFIGURATION_REVIEW", issues: validation.issues };
  if (!validation.valid) return { status: "invalid", nextAction: "CORRECT_CONFIGURATION", issues: validation.issues };

  const commercial = validateCommercialRequirements(product, configuration);
  if (!commercial.valid) return { status: "invalid", nextAction: "CORRECT_COMMERCIAL_REQUIREMENTS", commercial, issues: commercial.issues };

  const compatibility = assessCompatibility(product, configuration, compatibilityRules);
  if (compatibility.status === "unsupported") return { status: "blocked", nextAction: "CONTACT_HDC", compatibility, issues: [{ code: "APPLICATION_UNSUPPORTED", message: compatibility.reason ?? "This application is not currently supported." }] };
  if (compatibility.status === "needs_review" || compatibility.status === "needs_test") {
    return { status: "review", nextAction: "TECHNICAL_REVIEW", compatibility, issues: [{ code: "COMPATIBILITY_REVIEW_REQUIRED", message: compatibility.reason }] };
  }

  const pricing = lookupExactPrice(product, configuration, profile, matrixRows, asOf);
  if (pricing.status === "priced") return { status: "ready", nextAction: "ADD_TO_JOB", compatibility, pricing, issues: [] };
  const mode = product.commercialMode === "MATRIX" ? "QUOTE" : product.commercialMode;
  return {
    status: "quote_required",
    nextAction: mode === "TECHNICAL_REVIEW" ? "TECHNICAL_REVIEW" : "REQUEST_QUOTE",
    compatibility,
    pricing,
    issues: [{ code: "PRICE_NOT_APPROVED", message: "No exact approved price is available; request a quote." }],
  };
}

function deepFreeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze(child);
  }
  return value;
}

/** Build a reviewable immutable snapshot; persistence is left to the app adapter. */
export function createJobSnapshot({ product, configuration, evaluation, artworkFiles = [], createdAt = new Date().toISOString() }) {
  if (!product) throw new TypeError("A known product is required to create a job snapshot.");
  if (!isPlainObject(configuration)) throw new TypeError("Configuration must be an object.");
  return deepFreeze({
    schemaVersion: 1,
    product: { id: product.id, name: product.name, familyId: product.familyId, template: product.template, sourceRef: product.sourceRef },
    configuration: structuredClone(configuration),
    artworkFiles: structuredClone(artworkFiles),
    evaluation: structuredClone(evaluation),
    createdAt,
  });
}
