import { canonicalize } from "./evaluation.js";

/**
 * Owner-supplied A3 sheet price. This is a unit/base price, not a calculated
 * job total. Unknown material, cut, finish and quantity effects remain quote
 * questions; no price formula is inferred from this row.
 */
export const BASE_SHEET_PRICES = Object.freeze([
  Object.freeze({
    id: "a3-label-sheet-owner-2026-10-05",
    productId: "labels-stickers",
    formatField: "finished_size",
    format: "A3",
    currency: "PKR",
    unitPrice: 2500,
    unit: "sheet",
    basis: "owner_supplied_base_sheet_price",
    source: "User-provided price: an A3 sticker or label sheet is PKR 2,500.",
    effectiveFrom: "2026-10-05",
    status: "approved",
  }),
  Object.freeze({
    id: "a3-sticker-sheet-owner-2026-10-05",
    productId: "custom-sticker-sheets",
    formatField: "sheet_size",
    format: "A3",
    currency: "PKR",
    unitPrice: 2500,
    unit: "sheet",
    basis: "owner_supplied_base_sheet_price",
    source: "User-provided price: an A3 sticker or label sheet is PKR 2,500.",
    effectiveFrom: "2026-10-05",
    status: "approved",
  }),
]);

/**
 * Resolve the stated unit price for an exact A3 sheet. If any other job fields
 * are present, surface it as a base price and route the full job to quote; the
 * missing options must not be silently treated as included.
 */
export function lookupBaseSheetPrice(product, configuration, rows = BASE_SHEET_PRICES) {
  if (!product || !configuration || typeof configuration !== "object" || Array.isArray(configuration)) {
    return { status: "unavailable", reason: "A product and configuration object are required." };
  }
  const row = rows.find((candidate) => candidate.status === "approved"
    && candidate.productId === product.id
    && configuration[candidate.formatField] === candidate.format);
  if (!row) return { status: "no_match", reason: "No owner-approved base sheet price matches this product and size." };

  const formatOnly = canonicalize(configuration) === canonicalize({ [row.formatField]: row.format });
  return {
    status: formatOnly ? "base_price" : "base_price_quote_required",
    currency: row.currency,
    unitPrice: row.unitPrice,
    unit: row.unit,
    format: row.format,
    priceRowId: row.id,
    source: row.source,
    totalCalculated: false,
    nextAction: formatOnly ? "CONFIRM_JOB_SCOPE" : "REQUEST_QUOTE",
    note: formatOnly
      ? "PKR 2,500 per A3 sheet. Confirm job scope before treating this as a final order price."
      : "PKR 2,500 per A3 sheet is the recorded base price. Other selected job details require a quote; no total has been calculated.",
  };
}
