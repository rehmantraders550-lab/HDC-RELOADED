/**
 * Profile-driven artwork preflight. Numeric thresholds and acceptance rules
 * must come from the selected process/substrate/finishing profile; this module
 * intentionally contains no universal bleed, resolution, ink-limit or trapping
 * values.
 */
export function evaluateArtworkPreflight({ processId, profile, findings = [] }) {
  if (!processId) return { status: "needs_review", nextAction: "IDENTIFY_PROCESS", blockers: [], warnings: [], issues: [{ code: "PROCESS_REQUIRED", message: "Identify the intended production process before choosing preflight rules." }] };
  if (!profile || profile.status !== "approved") {
    return { status: "needs_profile", nextAction: "SELECT_APPROVED_PROFILE", blockers: [], warnings: [], issues: [{ code: "PREFLIGHT_PROFILE_UNAPPROVED", message: "No approved preflight profile is available for this job." }] };
  }
  if (profile.processId !== processId) {
    return { status: "needs_review", nextAction: "SELECT_MATCHING_PROFILE", blockers: [], warnings: [], issues: [{ code: "PROCESS_PROFILE_MISMATCH", message: "The preflight profile does not match the selected process." }] };
  }

  const requiredChecks = profile.requiredChecks ?? [];
  const byCheck = new Map(findings.map((item) => [item.check, item]));
  const blockers = [];
  const warnings = [];
  const issues = [];
  for (const check of requiredChecks) {
    const finding = byCheck.get(check.id);
    if (!finding) {
      issues.push({ code: "PREFLIGHT_CHECK_MISSING", check: check.id, message: `Required check '${check.label ?? check.id}' has no result.` });
      continue;
    }
    if (finding.status === "error") blockers.push({ check: check.id, detail: finding.detail ?? null });
    else if (finding.status === "warning") warnings.push({ check: check.id, detail: finding.detail ?? null });
    else if (finding.status !== "pass") issues.push({ code: "PREFLIGHT_RESULT_INVALID", check: check.id, message: "Preflight result must be pass, warning or error." });
  }

  const status = blockers.length ? "blocked" : issues.length ? "needs_review" : warnings.length ? "warning_review" : "passed";
  const nextAction = status === "blocked" ? "FIX_ARTWORK"
    : status === "needs_review" || status === "warning_review" ? "PREPRESS_REVIEW"
      : "READY_FOR_APPROVAL";
  return { status, nextAction, profileId: profile.id, profileVersion: profile.version, processId, blockers, warnings, issues };
}
