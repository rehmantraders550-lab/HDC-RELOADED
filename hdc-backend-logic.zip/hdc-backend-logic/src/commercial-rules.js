/** Owner-confirmed commercial constraints; price amounts remain quote/matrix data. */
export const MINIMUM_ORDER_RULES = Object.freeze({
  catalogues: Object.freeze({ minimumQuantity: 500, unit: "piece", source: "Owner-provided MOQ", effectiveFrom: "2026-10-06" }),
  posters: Object.freeze({ minimumQuantity: 500, unit: "piece", source: "Owner-provided MOQ", effectiveFrom: "2026-10-06" }),
});

export const COLOR_PRICE_RULES = Object.freeze({
  catalogues: Object.freeze({ field: "print_colors", allowedValues: Object.freeze([1, 2, 4]), source: "Owner-provided pricing basis", effectiveFrom: "2026-10-06" }),
  posters: Object.freeze({ field: "print_colors", allowedValues: Object.freeze([1, 2, 4]), source: "Owner-provided pricing basis", effectiveFrom: "2026-10-06" }),
});

/**
 * UV and UV DTF are common across most of HDC's product range, per owner.
 * This business-level guidance is not a product compatibility declaration:
 * specific process availability still requires an approved product profile.
 */
export const PROCESS_USAGE_GUIDANCE = Object.freeze({
  commonProcesses: Object.freeze(["uv-printing", "uv-dtf"]),
  scope: "most-products",
  source: "Owner-provided process guidance",
  effectiveFrom: "2026-10-06",
  productSpecificApprovalRequired: true,
});

export function validateCommercialRequirements(product, configuration) {
  if (!product || !configuration || typeof configuration !== "object" || Array.isArray(configuration)) {
    return { valid: false, issues: [{ code: "COMMERCIAL_CONFIGURATION_REQUIRED", message: "A product and configuration are required." }] };
  }
  const issues = [];
  const minimum = MINIMUM_ORDER_RULES[product.id];
  if (minimum) {
    const quantity = configuration.quantity;
    if (typeof quantity !== "number" || !Number.isInteger(quantity)) {
      issues.push({ code: "INVALID_QUANTITY", field: "quantity", message: "Quantity must be a whole number of pieces." });
    } else if (quantity < minimum.minimumQuantity) {
      issues.push({ code: "BELOW_MINIMUM_ORDER", field: "quantity", minimum: minimum.minimumQuantity, unit: minimum.unit, message: `${product.name} require a minimum order of ${minimum.minimumQuantity} pieces.` });
    }
  }

  const colorRule = COLOR_PRICE_RULES[product.id];
  if (colorRule && !colorRule.allowedValues.includes(configuration[colorRule.field])) {
    issues.push({ code: "UNSUPPORTED_COLOR_COUNT", field: colorRule.field, allowedValues: colorRule.allowedValues, message: `Select ${colorRule.allowedValues.join(", ")} print colours for the approved price basis.` });
  }
  return { valid: issues.length === 0, issues };
}
